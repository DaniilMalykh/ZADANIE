// TODO: дополнить определение класса размерами и позицией
class Square  {
    // TODO: унаследовать от Figure, реализовать area()
    // TODO: реализовать интерфейс Transforming
}