interface Movable {
    // заказ на реализацию некоторых функций
    fun move(dx: Int, dy: Int)
}